<?php


$dynamicTexBox=$_POST['dynamicTexBox'];

echo $dynamicTexBox;

	?>