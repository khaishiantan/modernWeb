<?php
// php code file here.
$num1=$_POST['no1'];// first number
$num2=$_POST['no2'];// second number 

$ans= $num1+$num2;

echo "Adition Of Two Number Using ajax Call Demo Is: " .$ans;
?>